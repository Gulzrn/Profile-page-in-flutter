// // #include <graphics.h>
// // #include <fstream>
// // #include <iostream>
// // #include <string>
// // #include <conio.h> // For getch()
// // #include "stack_implementation.cpp"
// // using namespace std;

// // struct Command
// // {
// //     enum Operation
// //     {
// //         ADD,
// //         remove
// //     };
// //     Operation op;
// //     std::string text;
// // };
// // // * stack to store string

// // stack<Command> store;

// // void displayMenu()
// // {
// //     cleardevice();

// //     setbkcolor(CYAN);
// //     setcolor(WHITE);
// //     settextstyle(10, 0, 2); // Set Triplex font, horizontal text, medium size
// //     outtextxy(10, 50, const_cast<char *>(" GUL Note_pade"));
// //     outtextxy(10, 100, const_cast<char *>("1. Writte a new Text"));
// //     outtextxy(10, 150, const_cast<char *>("2. Save Text"));
// //     outtextxy(10, 200, const_cast<char *>("3. Exit"));
// //     outtextxy(10, 250, const_cast<char *>("Enter your choice:"));
// // }

// // // Function to display the current texts
// // void displayText(const string &text)
// // {
// //     cleardevice();
// //     setbkcolor(YELLOW);      // Set background color to yellow
// //     setcolor(BLACK);       // Set text color to black
// //     settextstyle(8, 0, 1); // Smaller text style
// //     outtextxy(50, 50, const_cast<char *>("Current Text:"));

// //     int y = 100; // Start position for text display
// //     for (size_t i = 0; i < text.length(); i += 10)
// //     { // Break text into lines
// //         string line = text.substr(i, 50);
// //         outtextxy(100, y, const_cast<char *>(line.c_str()));
// //         y += 30; // Move down for the next line
// //     }
// //     delay(2000); // Allow user to read the displayed text
// // }


// // // Main function
// // int main()
// // {
// //     int gd = DETECT, gm;
// //     initgraph(&gd, &gm, nullptr);

// //     string text = ""; // Text being edited
// //     char choice;

// //     while (true)
// //     {
// //         displayMenu(); // Show menu

// //         choice = getch(); // Get the user's choice

// //         switch (choice)
// //         {
// //         case '1':
// //         { // Edit text
// //             cleardevice();
// //             outtextxy(50, 50, const_cast<char *>("Enter your text (press ENTER to finish):"));

// //             string buffer = ""; // Use std::string for input
// //             int pos = 0;        // Current position in the buffer
// //             char ch;

// //             while ((ch = getch()) != 13)
// //             {
// //                 // Undo oprations
// //                 if (ch == 26 && !store.empty()) // CTRL+Z and stack is not empty
// //                 {
// //                     Command lastCommand = store.top();
// //                     store.pop();

// //                     if (lastCommand.op == Command::ADD)
// //                     {
// //                         // Remove the last added character
// //                         if (!buffer.empty())
// //                         {
// //                             buffer.pop_back();
// //                             pos--; // Update cursor position
// //                         }
// //                     }
// //                     else if (lastCommand.op == Command::remove)
// //                     {
// //                         // Re-add the last removed character
// //                         buffer += lastCommand.text;
// //                         pos++; // Update cursor position
// //                     }

// //                     // Clear the screen area and re-render the buffer
// //                     cleardevice(); // Clear graphics device
// //                     outtextxy(50, 50, const_cast<char *>("Enter your text (press ENTER to finish):"));
// //                     for (size_t i = 0; i < buffer.length(); i++)
// //                     {
// //                         char temp[2] = {buffer[i], '\0'};
// //                         outtextxy(50 + (i * 10), 100, temp);
// //                     }
// //                 }

// //                 else if (ch == 8 && pos > 0)
// //                 {          // Handle backspace
// //                     pos--; // Decrease position
// //                     // * delete text
// //                     char deletedChar = buffer.back(); // Get the last character that is being removed
// //                     outtextxy(50, 50, const_cast<char *>(std::string(1, deletedChar).c_str()));
// //                     buffer.pop_back(); // Remove the last character from the string

// //                     setfillstyle(SOLID_FILL, BLUE);
// //                     bar(50 + (pos * 10), 100, 50 + (pos * 10) + 10, 120); // Clear the character's space
// //                     // *creating cmmnd instance
// //                     Command remv_string;
// //                     remv_string.text = deletedChar;
// //                     remv_string.op = Command::remove;
// //                     store.push(remv_string);
// //                 }
// //                 else if (pos < 999 && ch != 8)
// //                 {                 // Append character
// //                     buffer += ch; // Add the character to the string
// //                     char temp[2] = {ch, '\0'};
// //                     outtextxy(50 + (pos * 10), 100, temp); // Display the character at the correct position
// //                     pos++;
// //                     Command add_string;
// //                     add_string.text = ch;
// //                     add_string.op = Command::ADD;
// //                     store.push(add_string);
// //                 }
// //             }

// //             text = buffer; // Update the text variable with the entered string
// //             break;
// //         }

// //         case '2':
// //         { // Save text
// //             ofstream file("notepad.txt");
// //             if (file.is_open())
// //             {
// //                 file << text;
// //                 file.close();
// //                 cleardevice();
// //                 outtextxy(50, 50, const_cast<char *>("Text saved to 'notepad.txt'"));
// //             }
// //             else
// //             {
// //                 cleardevice();
// //                 outtextxy(50, 50, const_cast<char *>("Error: Could not save the text."));
// //             }
// //             delay(2000); // Allow user to read the message
// //             break;
// //         }
// //         case '3':
// //         { // Exit
// //             cleardevice();
// //             outtextxy(50, 50, const_cast<char *>("Exiting..."));
// //             delay(1000);
// //             closegraph();
// //             return 0;
// //         }
// //         default:
// //         { // Invalid choice
// //             cleardevice();
// //             outtextxy(50, 50, const_cast<char *>("Invalid choice! Try again."));
// //             delay(500); // Allow user to read the message
// //             break;
// //         }
// //         }
// //     }

// //     closegraph();
// //     return 0;
// // }




// #include <graphics.h>
// #include <fstream>
// #include <iostream>
// #include <string>
// #include <conio.h>
// using namespace std;

// // Constants
// const int MAX_LINES = 100;     // Maximum number of lines
// const int MAX_CHARS_PER_LINE = 100; // Maximum characters per line

// // Cursor properties
// int cursorX = 50;   // Initial cursor X position
// int cursorY = 100;  // Initial cursor Y position
// int charWidth = 10; // Width of a character
// int lineHeight = 20; // Height of a line

// // Text buffer
// char textBuffer[MAX_LINES][MAX_CHARS_PER_LINE] = {0}; // Initialized to empty
// int lineLengths[MAX_LINES] = {0}; // Tracks the length of each line

// // Function to draw the cursor
// void drawCursor() {
//     setcolor(WHITE);
//     line(cursorX, cursorY, cursorX, cursorY + lineHeight - 5); // Draw cursor as a vertical line
// }

// // Function to erase the cursor
// void eraseCursor() {
//     setfillstyle(SOLID_FILL, BLACK); // Background color
//     bar(cursorX, cursorY, cursorX + charWidth, cursorY + lineHeight - 5); // Erase the cursor area
// }

// // Function to display the text
// void displayText() {
//     cleardevice(); // Clear screen
//     setbkcolor(BLACK); // Background color
//     setcolor(WHITE);   // Text color
//     settextstyle(8, 0, 1); // Text style

//     int y = 100; // Start drawing text from this position
//     for (int i = 0; i < MAX_LINES; i++) {
//         if (lineLengths[i] > 0) {
//             outtextxy(50, y, textBuffer[i]);
//         }
//         y += lineHeight; // Move down for the next line
//     }
//     drawCursor(); // Ensure the cursor is visible
// }

// // Function to handle cursor movement
// void moveCursor(char key) {
//     eraseCursor(); // Remove the current cursor
//     int currentLine = (cursorY - 100) / lineHeight; // Calculate current line based on cursorY

//     switch (key) {
//         case 75: // Left arrow
//             if (cursorX > 50) {
//                 cursorX -= charWidth; // Move left
//             } else if (currentLine > 0) { // Move to previous line if possible
//                 cursorY -= lineHeight;
//                 cursorX = 50 + charWidth * lineLengths[currentLine - 1];
//             }
//             break;

//         case 77: // Right arrow
//             if (cursorX < 50 + charWidth * lineLengths[currentLine]) {
//                 cursorX += charWidth; // Move right
//             } else if (currentLine + 1 < MAX_LINES && lineLengths[currentLine + 1] > 0) { // Move to next line if possible
//                 cursorY += lineHeight;
//                 cursorX = 50;
//             }
//             break;

//         case 72: // Up arrow
//             if (currentLine > 0) {
//                 cursorY -= lineHeight; // Move up
//                 int prevLineLength = lineLengths[currentLine - 1];
//                 cursorX = min(cursorX, 50 + charWidth * prevLineLength); // Adjust to line length
//             }
//             break;

//         case 80: // Down arrow
//             if (currentLine + 1 < MAX_LINES && lineLengths[currentLine + 1] > 0) {
//                 cursorY += lineHeight; // Move down
//                 int nextLineLength = lineLengths[currentLine + 1];
//                 cursorX = min(cursorX, 50 + charWidth * nextLineLength); // Adjust to line length
//             }
//             break;
//     }

//     drawCursor(); // Draw the cursor at the new position
// }

// // Function to insert a character at the cursor position
// void insertCharacter(char ch) {
//     int currentLine = (cursorY - 100) / lineHeight; // Calculate current line based on cursorY
//     int cursorPos = (cursorX - 50) / charWidth;    // Calculate position within the line

//     // Shift characters to the right
//     for (int i = lineLengths[currentLine]; i > cursorPos; i--) {
//         textBuffer[currentLine][i] = textBuffer[currentLine][i - 1];
//     }

//     textBuffer[currentLine][cursorPos] = ch; // Insert character
//     lineLengths[currentLine]++;             // Increase line length
//     cursorX += charWidth;                   // Move cursor right
//     displayText();                          // Redraw the text
// }

// // Function to handle backspace
// void handleBackspace() {
//     int currentLine = (cursorY - 100) / lineHeight;
//     int cursorPos = (cursorX - 50) / charWidth;

//     if (cursorPos > 0) { // Remove character in the current line
//         for (int i = cursorPos - 1; i < lineLengths[currentLine] - 1; i++) {
//             textBuffer[currentLine][i] = textBuffer[currentLine][i + 1];
//         }
//         textBuffer[currentLine][lineLengths[currentLine] - 1] = '\0'; // Null-terminate
//         lineLengths[currentLine]--;
//         cursorX -= charWidth;
//     } else if (currentLine > 0) { // Merge with the previous line
//         int prevLineLength = lineLengths[currentLine - 1];
//         for (int i = 0; i < lineLengths[currentLine]; i++) {
//             textBuffer[currentLine - 1][prevLineLength + i] = textBuffer[currentLine][i];
//         }
//         lineLengths[currentLine - 1] += lineLengths[currentLine];
//         lineLengths[currentLine] = 0;
//         for (int i = currentLine; i < MAX_LINES - 1; i++) {
//             strcpy(textBuffer[i], textBuffer[i + 1]);
//             lineLengths[i] = lineLengths[i + 1];
//         }
//         cursorY -= lineHeight;
//         cursorX = 50 + charWidth * prevLineLength;
//     }
//     displayText();
// }

// // Function to save text to a file
// void saveTextToFile() {
//     ofstream file("notepad.txt");
//     if (file.is_open()) {
//         for (int i = 0; i < MAX_LINES; i++) {
//             if (lineLengths[i] > 0) {
//                 file << textBuffer[i] << endl;
//             }
//         }
//         file.close();
//         cleardevice();
//         outtextxy(50, 50, const_cast<char *>("Text saved to 'notepad.txt'"));
//         delay(2000);
//     } else {
//         cleardevice();
//         outtextxy(50, 50, const_cast<char *>("Error: Could not save the text."));
//         delay(2000);
//     }
// }

// // Main function
// int main() {
//     int gd = DETECT, gm;
//     initgraph(&gd, &gm, nullptr);

//     displayText(); // Display initial empty screen

//     char ch;
//     while (true) {
//         ch = getch();
//         if (ch == 27) { // ESC key to exit
//             break;
//         } else if (ch == 0 || ch == -32) { // Arrow keys
//             ch = getch(); // Get the second part of the arrow key code
//             moveCursor(ch);
//         } else if (ch == 8) { // Backspace
//             handleBackspace();
//         } else if (ch == 13) { // Enter key
//             int currentLine = (cursorY - 100) / lineHeight;
//             int cursorPos = (cursorX - 50) / charWidth;

//             for (int i = MAX_LINES - 1; i > currentLine + 1; i--) {
//                 strcpy(textBuffer[i], textBuffer[i - 1]);
//                 lineLengths[i] = lineLengths[i - 1];
//             }

//             strcpy(textBuffer[currentLine + 1], textBuffer[currentLine] + cursorPos);
//             lineLengths[currentLine + 1] = strlen(textBuffer[currentLine + 1]);
//             textBuffer[currentLine][cursorPos] = '\0';
//             lineLengths[currentLine] = cursorPos;

//             cursorY += lineHeight;
//             cursorX = 50;
//             displayText();
//         } else if (ch == 19) { // Ctrl+S to save
//             saveTextToFile();
//         } else { // Regular characters
//             insertCharacter(ch);
//         }
//     }

//     closegraph();
//     return 0;
// }


#include <graphics.h>
#include <fstream>
#include <iostream>
#include <string>
#include <conio.h>
#include <stack>
using namespace std;

// Constants
const int MAX_LINES = 100;
const int MAX_CHARS_PER_LINE = 100;

// Cursor properties
int cursorX = 50;
int cursorY = 100;
int charWidth = 10;
int lineHeight = 20;

// Text buffer
char textBuffer[MAX_LINES][MAX_CHARS_PER_LINE] = {0};
int lineLengths[MAX_LINES] = {0};

// Undo and Redo structures
struct Command {
    char operation;  // 'I' for insert, 'D' for delete
    int line;        // Line number
    int pos;         // Position in the line
    char ch;         // Character (for insert or delete)
};

stack<Command> undoStack;  // Stack for Undo
stack<Command> redoStack;  // Stack for Redo

// Function prototypes
void drawCursor();
void eraseCursor();
void displayText();
void moveCursor(char key);
void insertCharacter(char ch);
void handleBackspace();
void undo();
void redo();
void saveTextToFile();

// Function to draw the cursor
void drawCursor() {
    setcolor(WHITE);
    line(cursorX, cursorY, cursorX, cursorY + lineHeight - 5);
}

// Function to erase the cursor
void eraseCursor() {
    setfillstyle(SOLID_FILL, BLACK);
    bar(cursorX, cursorY, cursorX + charWidth, cursorY + lineHeight - 5);
}

// Function to display the text
void displayText() {
    cleardevice();
    setbkcolor(BLACK);
    setcolor(WHITE);
    settextstyle(8, 0, 1);

    int y = 100;
    for (int i = 0; i < MAX_LINES; i++) {
        if (lineLengths[i] > 0) {
            outtextxy(50, y, textBuffer[i]);
        }
        y += lineHeight;
    }
    drawCursor();
}

// Function to move the cursor
void moveCursor(char key) {
    eraseCursor();
    int currentLine = (cursorY - 100) / lineHeight;

    switch (key) {
        case 75:  // Left arrow
            if (cursorX > 50) {
                cursorX -= charWidth;
            } else if (currentLine > 0) {
                cursorY -= lineHeight;
                cursorX = 50 + charWidth * lineLengths[currentLine - 1];
            }
            break;
        case 77:  // Right arrow
            if (cursorX < 50 + charWidth * lineLengths[currentLine]) {
                cursorX += charWidth;
            } else if (currentLine + 1 < MAX_LINES && lineLengths[currentLine + 1] > 0) {
                cursorY += lineHeight;
                cursorX = 50;
            }
            break;
        case 72:  // Up arrow
            if (currentLine > 0) {
                cursorY -= lineHeight;
                int prevLineLength = lineLengths[currentLine - 1];
                cursorX = min(cursorX, 50 + charWidth * prevLineLength);
            }
            break;
        case 80:  // Down arrow
            if (currentLine + 1 < MAX_LINES && lineLengths[currentLine + 1] > 0) {
                cursorY += lineHeight;
                int nextLineLength = lineLengths[currentLine + 1];
                cursorX = min(cursorX, 50 + charWidth * nextLineLength);
            }
            break;
    }
    drawCursor();
}

// Function to insert a character at the cursor position
void insertCharacter(char ch) {
    int currentLine = (cursorY - 100) / lineHeight;
    int cursorPos = (cursorX - 50) / charWidth;

    for (int i = lineLengths[currentLine]; i > cursorPos; i--) {
        textBuffer[currentLine][i] = textBuffer[currentLine][i - 1];
    }

    textBuffer[currentLine][cursorPos] = ch;
    lineLengths[currentLine]++;
    cursorX += charWidth;

    // Add to Undo stack
    undoStack.push({'I', currentLine, cursorPos, ch});
    while (!redoStack.empty()) redoStack.pop();  // Clear Redo stack

    displayText();
}

// Function to handle backspace
void handleBackspace() {
    int currentLine = (cursorY - 100) / lineHeight;
    int cursorPos = (cursorX - 50) / charWidth;

    if (cursorPos > 0) {
        char removedChar = textBuffer[currentLine][cursorPos - 1];
        for (int i = cursorPos - 1; i < lineLengths[currentLine] - 1; i++) {
            textBuffer[currentLine][i] = textBuffer[currentLine][i + 1];
        }
        textBuffer[currentLine][lineLengths[currentLine] - 1] = '\0';
        lineLengths[currentLine]--;
        cursorX -= charWidth;

        // Add to Undo stack
        undoStack.push({'D', currentLine, cursorPos - 1, removedChar});
        while (!redoStack.empty()) redoStack.pop();  // Clear Redo stack

        displayText();
    }
}

// Function to undo the last action
// Function to undo the last action
void undo() {
    if (!undoStack.empty()) {
        Command lastCommand = undoStack.top();
        undoStack.pop();
        redoStack.push(lastCommand);  // Save the undone action for Redo

        eraseCursor();

        if (lastCommand.operation == 'I') {  // Undo insertion
            int currentLine = lastCommand.line;
            int cursorPos = lastCommand.pos;

            // Remove the inserted character
            for (int i = cursorPos; i < lineLengths[currentLine] - 1; i++) {
                textBuffer[currentLine][i] = textBuffer[currentLine][i + 1];
            }
            textBuffer[currentLine][lineLengths[currentLine] - 1] = '\0';
            lineLengths[currentLine]--;
            cursorX = 50 + cursorPos * charWidth;
            cursorY = 100 + currentLine * lineHeight;

        } else if (lastCommand.operation == 'D') {  // Undo deletion
            int currentLine = lastCommand.line;
            int cursorPos = lastCommand.pos;
            char deletedChar = lastCommand.ch;

            // Shift characters to the right
            for (int i = lineLengths[currentLine]; i > cursorPos; i--) {
                textBuffer[currentLine][i] = textBuffer[currentLine][i - 1];
            }
            textBuffer[currentLine][cursorPos] = deletedChar;
            lineLengths[currentLine]++;
            cursorX = 50 + (cursorPos + 1) * charWidth;
            cursorY = 100 + currentLine * lineHeight;

        } else if (lastCommand.operation == 'N') {  // Undo new line
            int currentLine = lastCommand.line;

            // Merge lines back
            int pos = lineLengths[currentLine - 1];
            for (int i = 0; i < lineLengths[currentLine]; i++) {
                textBuffer[currentLine - 1][pos + i] = textBuffer[currentLine][i];
            }
            lineLengths[currentLine - 1] += lineLengths[currentLine];
            textBuffer[currentLine][0] = '\0';
            lineLengths[currentLine] = 0;

            // Shift remaining lines up
            for (int i = currentLine; i < MAX_LINES - 1; i++) {
                strcpy(textBuffer[i], textBuffer[i + 1]);
                lineLengths[i] = lineLengths[i + 1];
            }
            cursorX = 50 + pos * charWidth;
            cursorY = 100 + (currentLine - 1) * lineHeight;
        }

        displayText();
    }
}

// Function to redo the last undone action
// Function to redo the last undone action
void redo() {
    if (!redoStack.empty()) {
        Command lastCommand = redoStack.top();
        redoStack.pop();
        undoStack.push(lastCommand); // Save the redone action back to Undo stack

        eraseCursor();

        if (lastCommand.operation == 'I') {  // Redo insertion
            int currentLine = lastCommand.line;
            int cursorPos = lastCommand.pos;

            // Shift characters to the right
            for (int i = lineLengths[currentLine]; i > cursorPos; i--) {
                textBuffer[currentLine][i] = textBuffer[currentLine][i - 1];
            }
            textBuffer[currentLine][cursorPos] = lastCommand.ch;
            lineLengths[currentLine]++;
            cursorX = 50 + (cursorPos + 1) * charWidth;
            cursorY = 100 + currentLine * lineHeight;

        } else if (lastCommand.operation == 'D') {  // Redo deletion
            int currentLine = lastCommand.line;
            int cursorPos = lastCommand.pos;

            // Remove the character at the position
            for (int i = cursorPos; i < lineLengths[currentLine] - 1; i++) {
                textBuffer[currentLine][i] = textBuffer[currentLine][i + 1];
            }
            textBuffer[currentLine][lineLengths[currentLine] - 1] = '\0';
            lineLengths[currentLine]--;
            cursorX = 50 + cursorPos * charWidth;
            cursorY = 100 + currentLine * lineHeight;

        } else if (lastCommand.operation == 'N') {  // Redo new line
            int currentLine = lastCommand.line;
            int cursorPos = lastCommand.pos;

            for (int i = MAX_LINES - 1; i > currentLine; i--) {
                strcpy(textBuffer[i], textBuffer[i - 1]);
                lineLengths[i] = lineLengths[i - 1];
            }

            strcpy(textBuffer[currentLine], textBuffer[currentLine - 1] + cursorPos);
            lineLengths[currentLine] = strlen(textBuffer[currentLine]);
            textBuffer[currentLine - 1][cursorPos] = '\0';
            lineLengths[currentLine - 1] = cursorPos;

            cursorY = 100 + currentLine * lineHeight;
            cursorX = 50;
        }

        displayText();
    }
}


// Function to save text to a file
void saveTextToFile() {
    ofstream file("notepad.txt");
    if (file.is_open()) {
        for (int i = 0; i < MAX_LINES; i++) {
            if (lineLengths[i] > 0) {
                file << textBuffer[i] << endl;
            }
        }
        file.close();
        cleardevice();
        outtextxy(50, 50, const_cast<char *>("Text saved to 'notepad.txt'"));
        delay(2000);
    } else {
        cleardevice();
        outtextxy(50, 50, const_cast<char *>("Error: Could not save the text."));
        delay(2000);
    }
}

// Main function
int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, nullptr);

    displayText();

    char ch;
    while (true) {
        ch = getch();
        if (ch == 27) {  // ESC key
            break;
        } else if (ch == 0 || ch == -32) {  // Arrow keys
            ch = getch();
            moveCursor(ch);
        } else if (ch == 8) {  // Backspace
            handleBackspace();
        } else if (ch == 19) {  // Ctrl+S
            saveTextToFile();
        } else if (ch == 26) {  // Ctrl+Z (Undo)
            undo();
        } else if (ch == 25) {  // Ctrl+Y (Redo)
            redo();
        } else {  // Insert character
            insertCharacter(ch);
        }
    }

    closegraph();
    return 0;
}
