#include <graphics.h>
#include <iostream>
#include <string>
using namespace std;

class Notepad {
private:
    string text;           
    int cursorPosition;   

public:
    Notepad() : text(""), cursorPosition(0) {}

    void addText(const string& newText) {
        text.insert(cursorPosition, newText);
        cursorPosition += newText.length(); 
    }

    void deleteText(int length) {
        if (length <= 0 || length > cursorPosition) return;
        text.erase(cursorPosition - length, length);      
        cursorPosition -= length;                       

    string getText() const { return text; }              
    int getCursorPosition() const { return cursorPosition; }
};

void displayGraphicalText(const Notepad& notepad) {
    cleardevice(); 

    rectangle(50, 50, 600, 400); 

    outtextxy(60, 60, const_cast<char*>(notepad.getText().c_str()));

    int cursorPosition = notepad.getCursorPosition();
    if (cursorPosition >= 0 && cursorPosition <= notepad.getText().length()) {
        string cursorText = "|";
        outtextxy(60 + cursorPosition * 8, 60, const_cast<char*>(cursorText.c_str())); 
}

int main() {
 
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "C:\\Turboc3\\BGI");

    Notepad notepad;
    int choice;

    do {
        displayGraphicalText(notepad);

        cout << "\nWelcome to Notepad-like Word Processor (Graphical Mode)!\n";
        cout << "1. Add text\n";
        cout << "2. Delete text\n";
        cout << "3. Exit\n";
        cout << "Please select an option (1-3): ";
        cin >> choice;

        cin.ignore(); 

        if (choice == 1) {
            string newText;
            cout << "Enter text to add: ";
            getline(cin, newText); 
            notepad.addText(newText);
        } else if (choice == 2) {
            int length;
            cout << "Enter number of characters to delete: ";
            cin >> length;
            notepad.deleteText(length); 
        } else if (choice == 3) {
            cout << "Exiting...\n";
        } else {
            cout << "Invalid option. Please try again.\n";
        }
    } while (choice != 3);

    closegraph();
    return 0;
}
